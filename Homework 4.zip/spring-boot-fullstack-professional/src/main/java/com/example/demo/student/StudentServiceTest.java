package com.example.demo.student;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

@ExtendWith(MockitoExtension.class)
class StudentServiceTest {

	@Mock
	private StudentRepository studentRepository;
	private StudentService underTest;

	@BeforeEach
	void setUp(){
		
		underTest = new StudentService(studentRepository);
	}


	@Test
	void canGetAllStudents(){
		//when
		underTest.GetAllStudents();
		//then
		verify(studentRepository).findAll();
	}

	@Test
	void canAddStudent(){
		//given
		Student student = new Student(
			"Jamila", 
			"jamila@gmail.com", 
			Gender.FEMALE
		);
		//when
		underTest.addStudent(student);

		//then
		ArgumentCaptor<Student> studentArgumentCaptor = 
			ArgumentCaptor.forClass(Student.class);
		
		verify(studentRepository)
			.save(studentArgumentCaptor.capture());

		Student capturedStudent = studentArgumentCaptor.getValue();

		assertThat(capturedStudent).isEqualTo(student);
	}

	@Test
	void willThrowWhenEmailIsTaken(){
		//given
		Student student = new Student(
			"Jamila", 
			"jamila@gmail.com", 
			Gender.FEMALE
		);

		given(studentRepository.selectExistsEmail(student.getEmail())
			.willReturn(true);

		//when
		//then
		assertThatThrownBy(() ->underTest.addStudent(student))
			.isInstanceOf(BadRequestException.class)
			.hasMessageContaining("Email " + student.getEmail() + " taken");

		verify(studentRepository, never()).save(any());

		
		
	}

	@Test
	@Disabled
	void deleteStudent(){
	}
}